<?php
  $user=$_POST["user"];
  $id=$_POST["id"];
  
  if($user==""){
  echo "数据错误";
  return;
  }
$btlj="./user/".$user."/lbsj/".$id;
unlink($btlj);
echo "删除成功";


?>