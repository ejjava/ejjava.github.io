<?php
  $user=$_POST["user"];
  $nr=$_POST["nr"];
  
  if($nr==""){
  echo "请输入要修改的密码";
  return;
  }

$lj="./user/".$user."/pass.txt";
file_put_contents($lj,$nr);
echo "修改成功";


?>