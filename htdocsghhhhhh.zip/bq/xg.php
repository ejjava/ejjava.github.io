<?php
  $user=$_POST["user"];
  $id=$_POST["id"];
  $bt=$_POST["bt"];
  $nr=$_POST["nr"];
  if($user==""){
  echo "数据错误";
  return;
  }


$btlj="./user/".$user."/lbsj/".$id;
$nra="标题〖".$bt."〗内容【".$nr."】";

file_put_contents($btlj,$nra);
echo "修改成功";

?>