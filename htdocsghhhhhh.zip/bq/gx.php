<?php
  echo file_get_contents("./data/gx.txt");
?>